from .chat import chat
from .cos import cos
from .embed import embed
from .route import route
from .training import trainFile