from .main import Tear
from .router.inner import Router
from .router.methods import chat, cos, embed, route, training