from .inner import Router
from .methods.chat import chat
from .methods.cos import cos
from .methods.embed import embed
from .methods.route import route
from .methods.training import trainFile